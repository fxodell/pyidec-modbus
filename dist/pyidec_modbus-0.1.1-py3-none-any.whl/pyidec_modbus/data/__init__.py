# Package data: fc6a_tagmap.json etc. loaded via importlib.resources
